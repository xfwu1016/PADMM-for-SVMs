#' @title AL1 
#' @description The proximal operator of Weighted L1 soft threshold operator
#' @param lambda1  Parameter tuning or regularization term parameter vector
#' @param etai  The constant for the proximal operators of the penalty
#' @param  bb  The constant vectors in the proximal operator
#' @return The solution for the proximal operators of Weighted L1
#' @export
AL1<-function(lambda1,etai,bb){
  beta_k=rep(0, length(bb))
  for (i in 1:length(bb)) {
    beta_k[i]=sign(bb[i])*max(0,abs(bb[i])-lambda1[i]/(etai))
    
  }
  return(beta_k)
}