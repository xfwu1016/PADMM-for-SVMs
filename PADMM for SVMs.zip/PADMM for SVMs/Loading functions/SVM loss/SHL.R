SHL=function(x,mu){
r=rep(0,length(x))
for(i in 1:length(r)){
I=0
if(r[i]<0){I=1}
r[i]=(n*mu+2*I)*x[i]/(n*mu+2)
}
return(r)
}