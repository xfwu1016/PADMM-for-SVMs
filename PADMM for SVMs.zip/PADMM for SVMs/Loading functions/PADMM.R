PADMM<- function(X,y,Loss,Pen,lam,tau,M){
  if (Loss == "Hinge"){
    Ploss = HL
  }else if(Loss == "Least squares"){ Ploss = LSL}else 
    if(Loss == "Squared hinge"){Ploss = SHL}else 
      if(Loss == "Huberized pinball"){Ploss = HPL}else
        if(Loss == "Pinball"){Ploss = PL}else{Ploss = HHL}
  tau = tau
  n = nrow(X)
  p = ncol(X)
  begint <- proc.time()
  ite = 500
  gam = 10^1
  nu  = 0.999
  #M = 1
  #m=1
  alphaM = matrix(0.01,p,M)
  beta_0= matrix(0.01,p,1) #old
  beta_t=matrix(0.01,p,1) #tilde
  beta_u=matrix(0.01,p,1) #new
  betaM= matrix(0.01,p,M)
  betaU=matrix(0.01,p,M)
  r1M=matrix(0.01,n/M,M)
  r1t=matrix(0.01,n/M,M)
  r1U=matrix(0.01,n/M,M)
  r2M=matrix(0.01,n/M,M)
  r2t=matrix(0.01,n/M,M)
  r2U=matrix(0.01,n/M,M)
  uM=matrix(0.01,p,M)
  uU=matrix(0.01,p,M)
  vM=matrix(0.01,n/M,M)
  vU=matrix(0.01,n/M,M)
  group <- list()
  Inv_array <- array(0, dim=c(p, p, M))
  for (aa in 1:M) {
    group[[aa]] <- (1:n)[(n/M*(aa-1)+1) : (n/M*aa)]
  }
  
  for (aa in 1:M) {
    Inv_array[,,aa] = X_inv(X[group[[aa]],])
  }
  
  
  k=0
  repeat{
    #�ӷ�����
    time=rep(0,M)
    for (m in 1:M) {
      begin <- proc.time()
      uU[,m] =   uM[,m] + gam*(betaM[,m] - beta_t)
      vU[,m] =   vU[,m] + gam*(y[group[[m]]] - X[group[[m]],]%*%betaM[,m] -  r1t[,m] + r2t[,m])
      bbm = t(X[group[[m]],])%*%(y[group[[m]]] -  r1M[,m] + r2M[,m] + vU[,m]/gam)- (uU[,m])/gam + beta_0
      betaU[,m] = Inv_array[,,m]%*%bbm  ####��Ҫ��������
      #
      r1t[,m] = Ploss(y[group[[m]]] + vU[,m]/gam - X[group[[m]],]%*%betaU[,m],gam)
      r2t[,m] = Ploss(y[group[[m]]] + vU[,m]/gam - X[group[[m]],]%*%betaU[,m],gam)
      #rrr[,m]=y[group[[m]]] + dM[,m]/mu - X[group[[m]],]%*%betaU[,m]
      #r1t[,m] = pos(y[group[[m]]] - X[group[[m]],]%*%betaU[,m] + r2U[,m] + (vU[,m]-tau)/gam) 
      #r2t[,m] = pos(-y[group[[m]]]+ X[group[[m]],]%*%betaU[,m] + r1t[,m] - (vU[,m] + 1 - tau)/gam) 
      #У��
      r1U[,m] = (1-nu)*r1M[,m] + nu*r1t[,m] - nu*(r2M[,m] -r2t[,m])
      r2U[,m] =  (1-nu)*r2M[,m] + nu*r2t[,m]
      #�贫���
      alphaM[,m] = betaU[,m] + uU[,m]/gam
      end <- proc.time()
      time[m]=(end-begin)[3]
    }
    ###���ķ�����
    bb = rowMeans(alphaM) 
    beta_t=LASSO(lam,gam*M,bb)
    beta_u  = (1-nu)*beta_0 + nu*beta_t
    Perror=sqrt(sum((beta_u-beta_0)^2))/max(1,sqrt(sum(beta_0^2)))
    if(((Perror<1*10^-3)&(k>30))|(k>ite-1)){break}
    beta_0 = beta_u
    betaM = betaU
    r1M = r1U
    r2M = r2U
    uM = uU
    vM = vU
    k = k + 1
  }
  endt <- proc.time()
  Tol=endt-begint
  Time = Tol[3] - sum(time)+max(time)
  
  #ite = k ####��������LLA
  if(Pen != "LASSO"){
    ite_la = k
    time_la  = Time
    begint <- proc.time()
    if(Pen == "mcp"){lambdav = mcpder(a=3,beta_u, lam)}else{
      lambdav = scadder(a=3.7,beta_u,lam)
    }
    k=0
    repeat{
      #�ӷ�����
      time=rep(0,M)
      for (m in 1:M) {
        begin <- proc.time()
        uU[,m] =   uM[,m] + gam*(betaM[,m] - beta_t)
        vU[,m] =   vU[,m] + gam*(y[group[[m]]] - X[group[[m]],]%*%betaM[,m] -  r1t[,m] + r2t[,m])
        bbm = t(X[group[[m]],])%*%(y[group[[m]]] -  r1M[,m] + r2M[,m] + vU[,m]/gam)- (uU[,m])/gam + beta_0
        betaU[,m] = Inv_array[,,m]%*%bbm  ####��Ҫ��������
        #
        
        r1t[,m] = Ploss(y[group[[m]]] + vU[,m]/gam - X[group[[m]],]%*%betaU[,m],gam)
        r2t[,m] = Ploss(y[group[[m]]] + vU[,m]/gam - X[group[[m]],]%*%betaU[,m],gam)
        #r1t[,m] = pos(y[group[[m]]] - X[group[[m]],]%*%betaU[,m] + r2U[,m] + (vU[,m]-tau)/gam) 
        #r2t[,m] = pos(-y[group[[m]]]+ X[group[[m]],]%*%betaU[,m] + r1t[,m] - (vU[,m] + 1 - tau)/gam) 
        #У��
        r1U[,m] = (1-nu)*r1M[,m] + nu*r1t[,m] - nu*(r2M[,m] -r2t[,m])
        r2U[,m] =  (1-nu)*r2M[,m] + nu*r2t[,m]
        #�贫���
        alphaM[,m] = betaU[,m] + uU[,m]/gam
        end <- proc.time()
        time[m]=(end-begin)[3]
      }
      ###���ķ�����
      bb = rowMeans(alphaM) 
      beta_u=AL1(lambdav,gam*M,bb)
      beta_u  = (1-nu)*beta_0 + nu*beta_t
      Perror=sqrt(sum((beta_u-beta_0)^2))/max(1,sqrt(sum(beta_0^2)))
      if(((Perror<1*10^-3)&(k>4))|(k>20)){break}
      beta_0 = beta_u
      betaM = betaU
      r1M = r1U
      r2M = r2U
      uM = uU
      vM = vU
      k = k + 1
    }
    endt <- proc.time()
    Tol = endt-begint
    Time = Tol[3] - sum(time)+max(time)
    Time = Time + time_la
    k = ite_la + k
  }
  result=list(beta_u=beta_u,K=k,t = Time )
  return(result)
}