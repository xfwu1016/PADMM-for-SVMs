##Load loss functions
source("HL.R")#hinge loss
source("LSL.R")#least squares loss
source("SHL.R")#squared hinge loss
source("HPL.R")#huberized pinball loss
source("PL.R")#pinball loss
source("HHL.R")#huberized hinge loss

## Load  regularization terms
source("LASSO.R")#Lasso
source("AL1.R")#Adaptive Lasso(LLA requires it)
source("MCP.R")#MCP
source("mcpder.R")#First derivative of MCP(LLA requires it)
source("SCAD.R")#SCAD
source("scadder.R")#First derivative of SCAD(LLA requires it)
source("X_inv.R")#Calculate the inverse of a matrix

###Load Main algorithm function
source("PADMM")


#####Simulation experiment
n=1000
p=200
q=10
rho <- 0.5 #Can be adjusted to 0.2, 0.4, 0.6
#First class
x1 <- matrix(rnorm(n*q,0,1), n, q)
x2 <- matrix(rnorm(n*(p-q),0,1), n, p-q)
corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_1 <- cbind(x1%*% chol(corrmat1)+1, x2%*% chol(corrmat2))
#Second class
x1 <- matrix(rnorm(n*q,0,1), n, q)
x2 <- matrix(rnorm(n*(p-q),0,1), n, p-q)
corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_2 <- cbind(x1%*% chol(corrmat1)-1, x2%*% chol(corrmat2))
##Data preparation
X0= rbind(X_1,X_2)
X0 = cbind(matrix(1,nrow=2*n,1),X0)
y_label=c(rep(1,n),rep(-1,n))
##Test dataset
nt=500
#First class
x1 <- matrix(rnorm(nt*q,0,1), nt, q)
x2 <- matrix(rnorm(nt*(p-q),0,1), nt, p-q)
corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_1 <- cbind(x1%*% chol(corrmat1)+1, x2%*% chol(corrmat2))
#Second class
x1 <- matrix(rnorm(nt*q,0,1), nt, q)
x2 <- matrix(rnorm(nt*(p-q),0,1), nt, p-q)
corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_2 <- cbind(x1%*% chol(corrmat1)-1, x2%*% chol(corrmat2))
X0t = rbind(X_1,X_2)
X0t = cbind(matrix(1,nrow=2*nt,1),X0t)
yt_label=c(rep(1,nt),rep(-1,nt))
n = nrow(X0)
p = ncol(X0)
y = rep(1,n)
X = diag(y_label)%*%X0 
Loss="Pinball"
tau = 0.7
SVMmodel=PADMM(X,y,Loss="Least squares", Pen = "SCAD",lam=300*sqrt(log(p)/n),tau=0.7,M=1)
(SVMmodel$beta_u[1:11])/(SVMmodel$beta_u[2])
SVMmodel$K
SVMmodel$t
length(which(abs(SVMmodel$beta_u)>10^-4))
#Training set prediction accuracy
length(which((sign(X0%*%SVMmodel$beta_u))  - y_label==0))/n
# Test set prediction accuracy
length(which((sign(X0t%*%SVMmodel$beta_u))  - yt_label==0))/(2*nt)
